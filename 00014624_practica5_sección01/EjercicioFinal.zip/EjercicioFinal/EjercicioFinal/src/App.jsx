// Ejercicio Final — Guía 5
import React, { useEffect } from "react";

const SCIENTISTS = [
  {
    id: 1,
    name: "Maria Skłodowska-Curie",
    profession: "física y química",
    awards: [
      "Premio Nobel de Física",
      "Premio Nobel de Química",
      "Medalla Davy",
      "Medalla Matteucci"
    ],
    discoveries: "polonio (elemento químico)",
    imageUrl: "https://upload.wikimedia.org/wikipedia/commons/7/7e/Marie_Curie_c1920.jpg"
  },
  {
    id: 2,
    name: "Katsuko Saruhashi",
    profession: "geoquímica",
    awards: ["Premio Miyake de geoquímica", "Premio Tanaka"],
    discoveries: "un método para medir el dióxido de carbono en el agua de mar",
    imageUrl: "https://upload.wikimedia.org/wikipedia/en/0/08/Katsuko_Saruhashi.jpg"
  }
];


function avatarDataUrl(name, size = 80) {
  const initials = name
    .split(" ")
    .map((n) => n[0])
    .join("")
    .slice(0, 2)
    .toUpperCase();
  const bg = "#f0f4fb";
  const fg = "#12303f";
  const fontSize = Math.floor(size * 0.34);
  const svg = `<svg xmlns='http://www.w3.org/2000/svg' width='${size}' height='${size}' viewBox='0 0 ${size} ${size}'><rect rx='50%' width='100%' height='100%' fill='${bg}'/><text x='50%' y='50%' font-size='${fontSize}' font-family='Helvetica, Arial, sans-serif' fill='${fg}' dominant-baseline='middle' text-anchor='middle'>${initials}</text></svg>`;
  return `data:image/svg+xml;utf8,${encodeURIComponent(svg)}`;
}

function ScientistCard({ scientist }) {
  return (
    <article className="ef-card" aria-labelledby={`title-${scientist.id}`}>
     <header className="ef-card-head">
  <img
    className="ef-avatar"
    src={scientist.imageUrl}     // <- aquí usamos el link
    alt={`Foto de ${scientist.name}`}
    width="72"
    height="72"
  />
  <h3 id={`title-${scientist.id}`} className="ef-card-title">
    {scientist.name}
  </h3>
</header>


      <ul className="ef-list">
        <li>
          <strong>Profesión:</strong> {" "}
          <span>{scientist.profession}</span>
        </li>
        <li>
          <strong>Premios:</strong> {" "}
          <span>
            {scientist.awards.length} ({scientist.awards.join(", ")})
          </span>
        </li>
        <li>
          <strong>Descubrió:</strong> {" "}
          <span>{scientist.discoveries}</span>
        </li>
      </ul>
    </article>
  );
}

export default function App() {
  useEffect(() => {
    document.title = "Ejercicio Final — Guía 5";

    const existing = document.getElementById("ef-styles");
    if (existing) return;

    const css = `
      :root{ --bg:#ffffff; --muted:#6b7280; --accent:#0f172a; --card-border:#d1d5db }
      html,body,#root{height:100%}
      body{
        font-family: Inter, ui-sans-serif, system-ui, -apple-system, "Segoe UI", Roboto, "Helvetica Neue", Arial;
        margin:0;
        background: #f7fafc;
        color: var(--accent);
        -webkit-font-smoothing:antialiased;
        -moz-osx-font-smoothing:grayscale;
      }
      main.ef-page{
        max-width:900px;
        margin:36px auto;
        padding:20px;
      }
      .ef-title{
        font-size:22px;
        font-weight:800;
        margin:8px 0 18px 6px;
      }

      .ef-list-section{
        display:flex;
        flex-direction:column;
        gap:18px;
      }

      .ef-card{
        background:var(--bg);
        border:1px solid var(--card-border);
        border-radius:8px;
        padding:18px;
        box-shadow: 0 1px 0 rgba(12,15,20,0.02);
      }

      .ef-card-head{
        display:flex;
        align-items:center;
        gap:14px;
      }

      .ef-avatar{
        width:72px;
        height:72px;
        border-radius:50%;
        flex-shrink:0;
      }

      .ef-card-title{
        margin:0;
        font-size:18px;
        font-weight:700;
      }

      .ef-list{
        margin:14px 0 0 8px;
        padding-left:18px;
      }
      .ef-list li{
        margin-bottom:10px;
        line-height:1.35;
      }
      .ef-list strong{display:inline-block; width:96px;}

      /* Adaptaciones para pantallas pequeñas */
      @media (max-width:520px){
        main.ef-page{padding:12px; margin:20px}
        .ef-card{padding:12px}
        .ef-avatar{width:56px;height:56px}
        .ef-card-title{font-size:16px}
        .ef-list strong{width:86px}
      }
    `;

    const style = document.createElement("style");
    style.id = "ef-styles";
    style.appendChild(document.createTextNode(css));
    document.head.appendChild(style);
  }, []);

  return (
    <main className="ef-page">
      <h1 className="ef-title">Científicos Notables</h1>

      <section className="ef-list-section" aria-label="Lista de científicos notables">
        {SCIENTISTS.map((s) => (
          <ScientistCard key={s.id} scientist={s} />
        ))}
      </section>
    </main>
  );
}
